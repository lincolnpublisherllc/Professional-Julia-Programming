function slow_sum(n)
    s = 0
    for i in 1:n
        s += i
    end
    return s
end
