9.1.1 Benchmarking with @btime
BenchmarkTools.jl provides accurate, repeatable performance measurements, accounting for compilation overhead and variability.
using BenchmarkTools
