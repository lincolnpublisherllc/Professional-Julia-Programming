Profile memory usage with @allocated:
@allocated sum_squares!(rand(10_000))
