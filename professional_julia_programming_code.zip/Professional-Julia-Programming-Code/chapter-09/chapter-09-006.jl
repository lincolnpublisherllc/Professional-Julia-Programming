function parallel_sum(arr)
    s = ThreadsAtomic{Int}(0)
    @threads for i in eachindex(arr)
        s[] += arr[i]
    end
    return s[]
end
