Avoid using @time in production benchmarks—it includes compilation time.
Use @btime for reliable microbenchmarks.
