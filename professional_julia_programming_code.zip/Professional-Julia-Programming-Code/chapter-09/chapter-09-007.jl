Profile the simulation with @profile to locate hotspots.
Benchmark individual functions with @btime.
