function attach!(s::Subject, obs::Function)
    push!(s.observers, obs)
end
