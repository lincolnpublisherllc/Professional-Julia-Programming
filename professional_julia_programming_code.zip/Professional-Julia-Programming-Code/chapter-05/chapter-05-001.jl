Julia uses module constructs to define namespaces:
module MathUtils
