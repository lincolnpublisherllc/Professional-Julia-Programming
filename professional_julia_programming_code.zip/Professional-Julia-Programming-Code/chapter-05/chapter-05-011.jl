abstract type Solver end
struct LinearSolver <: Solver end
struct NonLinearSolver <: Solver end
