function dot_product(a::Vector, b::Vector)
    return sum(a .* b)
end
