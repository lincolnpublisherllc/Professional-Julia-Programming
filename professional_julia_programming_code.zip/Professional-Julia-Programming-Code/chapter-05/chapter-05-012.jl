function create_solver(solver_type::String)
    solver_type == "linear" ? LinearSolver() : NonLinearSolver()
end
