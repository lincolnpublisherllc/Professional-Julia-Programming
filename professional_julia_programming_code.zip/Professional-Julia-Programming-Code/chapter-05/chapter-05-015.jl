function notify!(s::Subject)
    for obs in s.observers
        obs(s.state)
    end
end
