@variable(model, x >= 0)  # Asset allocation variables
@objective(model, Max, 2 * x)  # Maximize returns
