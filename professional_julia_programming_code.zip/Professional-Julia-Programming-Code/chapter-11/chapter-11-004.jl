@distributed for i in 1:10000
    shared_result[i] = simulate_task(i)
end
