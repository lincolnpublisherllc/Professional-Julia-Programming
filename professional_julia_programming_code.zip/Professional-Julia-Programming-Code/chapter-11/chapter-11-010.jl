Implement a real-time component using @async and WebSockets.jl.
Benchmark the system with BenchmarkTools.jl to optimize.
