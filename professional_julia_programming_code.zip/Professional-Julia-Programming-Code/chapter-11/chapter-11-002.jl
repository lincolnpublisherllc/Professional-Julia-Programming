function f!(du, u, p, t)
    du[1] = -2 * u[1]
end
