    for (x, y) in training_data
        gs = gradient(() -> loss(x, y), params(model))
        update!(optimizer, params(model), gs)
    end
end
