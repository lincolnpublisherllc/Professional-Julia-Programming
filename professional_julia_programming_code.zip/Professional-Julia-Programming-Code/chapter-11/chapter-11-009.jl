@async begin
    while true
        msg = take!(ch)
        println("Event: ", msg)
    end
end
