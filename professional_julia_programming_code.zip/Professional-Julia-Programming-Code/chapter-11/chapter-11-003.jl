Parallel Simulations with SharedVector or Distributed module for large-scale experiments.
using SharedVector
@everywhere begin
    function simulate_task(x)
        return x^2
    end
end
