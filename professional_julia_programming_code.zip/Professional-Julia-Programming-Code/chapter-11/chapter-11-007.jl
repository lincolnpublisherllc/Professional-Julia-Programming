Use HTTP.jl and WebSockets.jl to stream financial data and perform real-time analytics:
using WebSockets
