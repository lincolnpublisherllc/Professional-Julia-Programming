@async begin
    for i in 1:10
        put!(ch, i^2)
    end
end
