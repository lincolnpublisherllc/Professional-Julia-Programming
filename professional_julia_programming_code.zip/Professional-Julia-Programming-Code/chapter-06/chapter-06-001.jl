6.1.1 Threads.@threads
Threads.@threads enables parallel loops, dividing iterations across available threads.
using Base.Threads
