Use Distributed to spawn workers.
Implement Monte Carlo simulation using parallel loops.
