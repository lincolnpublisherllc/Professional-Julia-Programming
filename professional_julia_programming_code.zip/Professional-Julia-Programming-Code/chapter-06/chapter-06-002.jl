function parallel_sum(arr)
    s = Threads.Atomic{Int}(0)
    Threads.@threads for i in 1:length(arr)
        s[] += arr[i]
    end
    return s[]
end
