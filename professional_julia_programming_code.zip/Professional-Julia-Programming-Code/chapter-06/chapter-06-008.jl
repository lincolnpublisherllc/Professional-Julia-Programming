server = @async begin
    sock = Sockets.listen(8080)
    while true
        client = Sockets.accept(sock)
        @async Sockets.write(client, "Hello, Julia!\n")
    end
end
