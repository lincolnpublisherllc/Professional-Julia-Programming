using Distributed
addprocs(4)  # Add 4 worker processes
