push!(s::Stack, value) = push!(s.data, value)
pop!(s::Stack) = pop!(s.data)
