Julia allows defining custom data structures with mutable struct or struct.
mutable struct Stack{T}
    data::Vector{T}
end
