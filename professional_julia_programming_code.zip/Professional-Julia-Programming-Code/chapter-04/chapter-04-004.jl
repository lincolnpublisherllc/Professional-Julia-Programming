function insert!(node::TreeNode, val::Int)
    if val < node.val
        isnothing(node.left) ? (node.left = TreeNode(val, nothing, nothing)) : insert!(node.left, val)
    else
        isnothing(node.right) ? (node.right = TreeNode(val, nothing, nothing)) : insert!(node.right, val)
    end
end
