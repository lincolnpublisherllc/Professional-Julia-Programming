Implement a prototype using Julia for core computations.
Benchmark performance using Profiler and BenchmarkTools.jl.
