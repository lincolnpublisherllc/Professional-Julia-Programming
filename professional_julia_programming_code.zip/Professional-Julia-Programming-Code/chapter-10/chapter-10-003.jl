@everywhere begin
    function strategy(signal::Vector{Float64})
        # trading logic
    end
end
