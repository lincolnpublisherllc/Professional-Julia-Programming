Solution: Julia's Multi-Threading and Distributed Computing enable fast calculations for complex meshes.
@everywhere function fem_solver(mesh)
    # solve for stress/strain in a mesh using FEM
end
