function calculate_mean(arr::Vector{T}) where T
    return sum(arr) / length(arr)
end
