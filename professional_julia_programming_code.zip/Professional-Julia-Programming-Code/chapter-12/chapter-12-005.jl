function transform!(data::DataFrame, transformer::Function)
    for row in eachrow(data)
        row .= transformer(row)
    end
end
