function clean_data(data::DataFrame)
    return dropmissing(data)
end
