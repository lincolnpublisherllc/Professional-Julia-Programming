Fetch data from a public API using HTTP.jl.
Parse and transform data into a structured format (DataFrames.jl).
