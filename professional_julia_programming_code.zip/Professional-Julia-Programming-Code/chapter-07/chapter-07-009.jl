7.2.2 GraphQL APIs
Package: GraphQLClient.jl
using GraphQLClient
