7.2.1 RESTful APIs with HTTP.jl
using HTTP, JSON
