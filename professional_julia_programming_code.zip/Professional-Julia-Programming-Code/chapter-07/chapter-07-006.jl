response = HTTP.get("https://jsonplaceholder.typicode.com/users")
data = JSON.parse(String(response.body))
