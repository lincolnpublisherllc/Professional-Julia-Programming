conn = LibPQ.Connection("host=localhost dbname=testdb user=user password=secret")
LibPQ.execute(conn, "CREATE TABLE IF NOT EXISTS users(id SERIAL PRIMARY KEY, name TEXT, age INT)")
LibPQ.execute(conn, "INSERT INTO users(name, age) VALUES('Alice', 30)")
