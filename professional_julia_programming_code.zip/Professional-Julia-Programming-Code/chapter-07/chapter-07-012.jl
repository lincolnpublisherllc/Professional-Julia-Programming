# Load into SQLite
db = SQLite.DB("etl_db.sqlite")
SQLite.load!(df, db, "posts", temp=false)
SQLite.close(db)
