7.1.1 SQL Databases: PostgreSQL and SQLite
Packages: LibPQ.jl for PostgreSQL, SQLite.jl for SQLite.
