response = HTTP.get("https://jsonplaceholder.typicode.com/posts")
data = JSON.parse(String(response.body))
