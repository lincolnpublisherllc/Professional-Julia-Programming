    println("Name: ", user["name"], ", Email: ", user["email"])
end
