
As a reader of this book, you are entitled to companion resources that include sample code files, reference notes, and supporting materials to help you get the most from your learning.
To receive your materials, please send an email to info@lincolnpublishers.us with the subject line Companion Resources for [Professional Julia Programming]. Include your name and proof of purchase (order number or screenshot). We will reply with a link to download the files.
