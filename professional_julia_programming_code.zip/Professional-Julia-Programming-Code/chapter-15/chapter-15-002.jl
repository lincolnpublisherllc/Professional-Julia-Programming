Skills: JuMP.jl, TimeSeries.jl, DataFrames.jl, Optimization.jl.
6. Cloud Computing and Distributed Systems Architect
