Monitor persistent memory growth in long-running processes using task-local storage and object finalizers:
finalizer(x -> println("Object freed"), obj)
