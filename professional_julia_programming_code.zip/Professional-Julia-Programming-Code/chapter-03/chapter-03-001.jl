3.2.1 BenchmarkTools.jl
BenchmarkTools.jl allows precise benchmarking and memory measurement.
using BenchmarkTools
