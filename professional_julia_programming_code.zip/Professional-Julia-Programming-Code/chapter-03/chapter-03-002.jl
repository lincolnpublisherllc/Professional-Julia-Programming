@profile for i in 1:1000
    sum(rand(1000))
end
