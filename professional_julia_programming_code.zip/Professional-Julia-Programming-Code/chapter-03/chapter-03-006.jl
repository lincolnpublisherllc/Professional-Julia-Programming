3.4.2 Loop Unrolling and @simd
For manually written loops, the @simd macro enables vectorized execution:
function sum_squares(arr)
    s = 0.0
    @simd for x in arr
        s += x^2
    end
    return s
end
