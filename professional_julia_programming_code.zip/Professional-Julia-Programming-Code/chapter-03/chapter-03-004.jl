ptr = pointer(arr)
unsafe_store!(ptr, 10)
