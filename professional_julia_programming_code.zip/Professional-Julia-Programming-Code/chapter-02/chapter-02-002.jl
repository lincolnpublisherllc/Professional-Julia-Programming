@generated function add_types(a::T, b::T) where T
    return :(a + b)
end
