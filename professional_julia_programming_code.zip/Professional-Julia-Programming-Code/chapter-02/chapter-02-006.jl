function process(x::Union{Int, Float64})
    return x^2
end
