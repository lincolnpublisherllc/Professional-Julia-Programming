struct MatrixWrapper{T}
    data::Array{T,2}
end
